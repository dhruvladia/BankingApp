# FinAuth
It an Android app for mobile banking where we have implemented the authentication using fingerprints. For verifying the fingerprints we are not using image processing. Instead we are extracting the features and then comparing them with the help of NIST biometric softwares.
